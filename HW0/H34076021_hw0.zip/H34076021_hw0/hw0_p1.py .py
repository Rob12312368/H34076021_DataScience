
def mymultiple(sub): #call itself to deal with polynomials with more than two ()
    all=[]
    fir=sub[0]
    sec=sub[1]
    for i in fir:
        for j in sec:
            all.append(separate(i,j)) #同類項合併前的結果
    if len(sub)==2: #activates when there are only two elements in sub
        combine(all)
    else:
        sub.pop(0)#delete the original first element
        sub[0]=all#store the result 
        mymultiple(sub)

def separate(poly1,poly2): #separate poly element into coefficient, variable, and power
    #coefficient
    starindex1=poly1.find('*') # multiple sign
    starindex2=poly2.find('*')
    coeff1=1
    coeff2=1
    if starindex1 !=-1: # * exists
        coeff1=int(poly1[:starindex1])
    else:
        if poly1.find('-') != -1:
            coeff1=-1
            
    if starindex2 !=-1: # * exists
        coeff2=int(poly2[:starindex2])
    else:
        if poly2.find('-') != -1:
            coeff2=-1
    
    #variable
    variable1=''
    variable2=''
    for i in poly1:
        if i.isalpha():
            variable1+=i
    for i in poly2:
        if i.isalpha():
            variable2+=i
    
    #power
    power1=''
    power2=''
    for i in range(len(poly1)):
        if poly1[i].isalpha() and i!=len(poly1)-1:
            if poly1[i+1]=='^':
                power1+=poly1[i+2]
            else:
                power1+=('1')
        elif poly1[i].isalpha() and i==len(poly1)-1:
            power1+=('1')
    for i in range(len(poly2)):
        if poly2[i].isalpha() and i!=len(poly2)-1:
            if poly2[i+1]=='^':
                power2+=poly2[i+2]
            else:
                power2+=('1')    
        elif poly2[i].isalpha() and i==len(poly2)-1:
            power2+=('1')             
    
    
    #two elements multiple
    coeff=coeff1*coeff2
    variable='' 
    power=''
    for i, v in enumerate(variable1):
        index=variable2.find(v) 
        variable+=v #put all kinds of variables into variable
        if index != -1: #same variable
            power+=str(int(power1[i])+int(power2[index]))
        else:
            power+=power1[i]
    for i,v in enumerate(variable2): #go through variable2 to make sure all variables are included
        index=variable1.find(v)
        if index ==-1:
            variable+=v
            power+=power2[i]
    
      
    #This dictionary stores variable as keys and power as values 
    variable_power={}
    for i in range(len(variable)):
        variable_power[variable[i]]=power[i] 
    variable_power=dict(sorted(variable_power.items(),key=lambda item:item[0]))
    
    
    result=''
    result+=str(coeff)+'*'
    for key, value in variable_power.items():
        result+=key+'^'+value
    return result



def combine(all):
    final=''
    for i in range(len(all)):# compare every element with the rest
        temp=''
        if all[i]!='':
            temp=all[i]
        else:
            continue
        for j in range(i+1,len(all)):
            if all[j] != '':
                if temp[2:]==all[j][2:]:#if variables and powers are the same, they can be combined
                    coeff=0
                    if temp[0]=='-' and all[j][0]=='-':# to see if there are minus sign
                        coeff=int(temp[:2])+int(all[j][:2])
                    elif temp[0]=='-':
                        coeff=int(temp[:2])+int(all[j][0])
                    elif all[j][0]=='-':
                        coeff=int(temp[0])+int(all[j][:2])
                    else:
                        coeff=int(temp[0])+int(all[j][0])
                    temp=str(coeff)+'*'+all[i][2:]
                    all[j]=''
        final+=temp+','
    myprint(final[:-1])
    
def myprint(final):
    #print(type(final))
    
    final=final.replace('^1','').replace(',','+').replace('+-','-').replace('1*','') #delete a few redundant signs and numbers

    print(final)            
                
poly_string=input('Input the polynomials: ')
#poly_string='(A+2*B^2)(B+3*C^3)(2*A+B+C)'
poly_sub=poly_string.replace('(','')
poly_sub=poly_sub.split(')')[:-1] #every element in poly_sub is the elements in a ()

for i in range(len(poly_sub)): #use | to replace + to help separate
    if '-' in poly_sub[i]:
        index=poly_sub[i].find('-')
        temp=poly_sub[i][:index]+'|'+poly_sub[i][index:]
        poly_sub[i]=temp
    if '+' in poly_sub[i]:
        poly_sub[i]=poly_sub[i].replace('+','|')


for index, value in enumerate(poly_sub): #separate using |
    poly_sub[index]=value.split('|')


mymultiple(poly_sub)


