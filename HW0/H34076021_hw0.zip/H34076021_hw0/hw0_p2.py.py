def topthree(csvdata,field):
    ratings={}
    for data in csvdata:
        if data[field['year']]=='2016': #pick movies in 2016
            ratings[data[field['title']]]=data[field['rating']]
    top3={}
    top3={title:rating for title,rating in sorted(ratings.items(), key=lambda item:item[1], reverse=True)} #sort the dict
    #print(top3)
    print('Top-3 movies with the highest ratings: ',', '.join(list(top3.keys())[:3]) )#pick top3
    print('**********************************')
    
def topone(csvdata,field):
    scores={} #accumulate score
    times={} 
    average={}
    for data in csvdata:
        for actor in data[field['actors']].split('|'): #use split to separate
            actor=actor.strip() #use lstrip to eliminate space
            if data[field['revenue (millions)']] !='': #avoid null
                if actor not in scores.keys(): #if does not exist previously
                    scores[actor]=float(data[field['revenue (millions)']])
                    times[actor]=1
                else: #if does
                    scores[actor]+=float(data[field['revenue (millions)']])
                    times[actor]+=1
    for name, score in scores.items():
        average[name]=score/times[name]
    top1={}
    top1={name:revenue for name,revenue in sorted(average.items(), key=lambda item:item[1], reverse=True)} #sort the dict
    
    answer=[]
    for key, value in top1.items():
        if value==max(top1.values()):
            answer.append(key)
        else:
            break
    
    print('The actor generating the highest average revenue: ',", ".join(answer))
    
    #print('The actor generating the highest average revenue: ',list(top1.keys())[0])
    print('**********************************')
def emma_average(csvdata,field):
    count=0
    rating=0
    for data in csvdata:
        if 'Emma Watson' in data[field['actors']]:
            rating+=float(data[field['rating']])
            count+=1
    print('The average rating of Emma Watson’s movies: ',rating/count)  
    print('**********************************')
def most_actors(csvdata,field):
    cooperate={} #a dic with using set as value
    for data in csvdata:
        temp={}
        temp=set(map(lambda x:x.strip(), data[field['actors']].split('|'))) #seperate the actors
        #print(temp)
        if data[field['director']] not in cooperate.keys():
            cooperate[data[field['director']]]=temp
        else:
            cooperate[data[field['director']]]=cooperate[data[field['director']]].union(temp) #to avoid duplicate actors
    top3_dir={}
    top3_dir={director:actors for director, actors in sorted(cooperate.items(), key=lambda item:len(item[1]), reverse=True)} #sort the dict
    

    answer=[]
    top3=[]
    for key, value in top3_dir.items():
        top3.append(len(value))
        if len(top3)==3:
            break
    
    for key, value in top3_dir.items():
        if len(value) in top3:
            answer.append(key)
        else:
            break
    
    print('Top-3 directors who collaborate with the most actors: ',', '.join(answer))
    print('**********************************')
def most_genres(csvdata,field):
    genres={}
    sorted_genres={}
    for data in csvdata:
        temp={}
        temp=list(map(lambda x:x.strip(), data[field['actors']].split('|'))) #seperate the actors
        for actor in  temp:
            if actor not in genres.keys():
                genres[actor]=set(data[field['genre']].split('|')) #use set to prevent duplicate data
            else:
                genres[actor]=genres[actor].union(set(data[field['genre']].split('|'))) 
    sorted_genres={name:genre for name,genre in sorted(genres.items(), key=lambda item:len(item[1]), reverse=True)}
    
    answer=[]
    top2=[]
    for key, value in sorted_genres.items():
        top2.append(len(value))
        if len(top2)==2:
            break
    
    for key, value in sorted_genres.items():
        if len(value) in top2:
            answer.append(key)
        else:
            break
    
    
    
    print('Top-2 actors playing in the most genres of movies: ',", ".join(answer))
    print('**********************************')
def largest_gap(csvdata,field):
    years={}
    for data in csvdata:
        temp={}
        temp=list(map(lambda x:x.strip(), data[field['actors']].split('|'))) #seperate the actors
        for actor in temp:
            if actor not in years.keys():
                years[actor]=set([int(data[field['year']])])
            else:
                years[actor]=years[actor].union(set([int(data[field['year']])]))

    gap={}
    for actor, year in years.items():
        gap[actor]=max(year)-min(year) #count the largest gap year
    gap={actor:years for actor, years in sorted(gap.items(), key=lambda item:item[1], reverse=True)} #sort the dict


    answer=[]
    for key, value in gap.items():
        if value==max(gap.values()):
            answer.append(key)
    print('Top-3 actors whose movies lead to the largest maximum gap of years: ',", ".join(answer))
    print('**********************************')
def collaborate(csvdata,johnny=set()):
    johnny.add('Johnny Depp')
    needmore=False
    for data in csvdata:
        temp=[i.strip() for i in data[field['actors']].split('|')] #seperate the actors
        for actor in temp:
            old_length=len(johnny)
            if actor in johnny:
                johnny=johnny.union(set(temp)) #add the direct and indirect actors into the set
            if old_length != len(johnny):
                needmore=True
    if needmore:
        collaborate(csvdata,johnny)
    else:
        johnny.remove('Johnny Depp')
        print('All actors who collaborate with Johnny Depp in direct and indirect ways: ',", ".join(list(johnny)))
        
    
mycsv=open("IMDB-Movie-Data.csv","r") #open file
csvdata=[]
for line in mycsv:
    line=line[:-1] #delete '/n' at the end
    csvdata.append(line.split(',')) #split line by field
field={csvdata[0][i].lower():i for i in range(len(csvdata[0]))} #field name dic
csvdata=csvdata[1:] #delete field name
#print(csvdata)
topthree(csvdata,field)
topone(csvdata,field)
emma_average(csvdata,field)
most_actors(csvdata,field)
most_genres(csvdata,field)
largest_gap(csvdata,field)
collaborate(csvdata)